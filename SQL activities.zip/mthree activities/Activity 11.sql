USE personaltrainer;

SELECT  *
FROM login
WHERE EmailAddress LIKE '%.gov';