USE personaltrainer;

SELECT Name, levelId, Notes
FROM workout
WHERE LevelId=2;