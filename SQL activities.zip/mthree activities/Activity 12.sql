USE personaltrainer;

SELECT  *
FROM login
WHERE EmailAddress NOT LIKE '%.com';