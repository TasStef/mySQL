USE personaltrainer;

SELECT FirstName, LastName, City 
FROM client
WHERE City='Metairie';

