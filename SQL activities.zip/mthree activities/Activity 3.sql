USE personaltrainer;

SELECT *
FROM client
WHERE city="Metairie";