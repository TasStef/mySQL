USE personaltrainer;

SELECT EmailAddress
FROM login
WHERE ClientId = (
	SELECT  ClientId
	FROM client
	WHERE FirstName="Estrella" AND LastName="Bazely"
);
