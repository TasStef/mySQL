USE personaltrainer;

SELECT *
FROM client;