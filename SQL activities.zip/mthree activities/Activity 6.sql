USE personaltrainer;

SELECT Name, LevelId
FROM workout;