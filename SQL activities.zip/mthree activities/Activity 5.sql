USE personaltrainer;

SELECT *
FROM Goal;