USE personaltrainer;

SELECT *
FROM exercise;