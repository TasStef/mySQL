USE personaltrainer;

SELECT Name
FROM goal
WHERE GoalId IN (

	SELECT GoalId
	FROM workoutgoal
	WHERE workoutId = (
    
		SELECT  WorkoutId
		FROM workout
		WHERE Name="This Is Parkour"
	)
);