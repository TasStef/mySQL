USE personaltrainer;

SELECT *
FROM client
WHERE ClientId="818u7faf-7b4b-48a2-bf12-7a26c92de20c";